#include "AI.h"

int invokeSinglePlayerMode(void) {
  // AI.c
  adjustLevel();

  return 0;
}
