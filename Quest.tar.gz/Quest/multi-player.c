#include <stdio.h>

int invokeMultiPlayerMode(void) {
  printf("Mult-player mode begins!\n");

  return 0;
}
